# ATRS Repository Structure Guide

## Recommended GitHub/GitLab Layout

- /frontend/           - React-based Analyst Dashboard
- /backend/
  - /api/              - FastAPI endpoints
  - /ml/               - AI/LLM logic
  - /config/           - Auth, logging, secrets
- /infra/
  - /terraform/        - AWS EKS setup
  - /k8s/
    - /helm/           - Helm chart for deployment
    - /config/         - Secrets and ConfigMaps
- /ci-cd/
  - /github/           - GitHub Actions workflows
  - /tekton/           - (Optional) for K8s-native CI/CD
- /loadtest/           - Locust scripts
- /docs/               - Architecture diagrams, compliance docs

## Best Practices
- Use GitHub Secrets or GitLab CI Variables
- Use `infra/k8s/config/secrets.yaml` encrypted via Sealed Secrets or SOPS
- Apply version tags to all Docker images
- Use `main` for production, `dev` for staging branches
