## Compliance Overlay

### CMMC Level 3
- AC.1.001: Role-based access enforcement
- AU.2.042: Centralized logging via ELK
- IR.2.093: Red/Blue simulation-driven incident response

### DoD Classified
- DoDI 8500.01 compliant architecture
- CNSSI 1253 control baselines
- DISA STIG for OS, container, K8s, network

### NIST 800-53
- AC-17: Zero Trust + RBAC enforced
- SI-4: Active monitoring (Kibana dashboards)
- IR-4: Automated & human-in-loop incident response
