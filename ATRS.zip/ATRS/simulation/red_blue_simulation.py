class RedTeam:
    def attack(self):
        return {"vector": "phishing", "severity": "high"}

class BlueTeam:
    def defend(self, attack):
        if attack['vector'] == "phishing":
            return "Email filter activated"
        return "No response"
