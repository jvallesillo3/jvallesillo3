
from locust import HttpUser, task, between

class ATRSLoadTest(HttpUser):
    wait_time = between(1, 3)

    @task
    def login_and_detect(self):
        response = self.client.post("/api/v1/auth/login", json={"username": "analyst", "password": "secret"})
        token = response.json().get("token")
        headers = {"Authorization": f"Bearer {token}"}
        self.client.post("/api/v1/detect", json={"payload": [0.1]*100}, headers=headers)
