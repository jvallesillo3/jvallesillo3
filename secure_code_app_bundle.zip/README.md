# Secure App
This app demonstrates AES-JWT secure data transmission.
Includes full CI/CD, TLS, and monitoring.