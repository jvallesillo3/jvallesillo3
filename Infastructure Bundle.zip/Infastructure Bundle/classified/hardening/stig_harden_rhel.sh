
#!/bin/bash
# STIG hardening script for ATRS RHEL Node

echo "Applying DISA STIG RHEL Hardening..."

# Disable root SSH login
sed -i 's/^PermitRootLogin.*/PermitRootLogin no/' /etc/ssh/sshd_config
systemctl restart sshd

# Ensure firewall is active
systemctl enable firewalld
systemctl start firewalld

# Configure auditd
yum install -y audit
systemctl enable auditd
systemctl start auditd

# Password complexity
authconfig --passalgo=sha512 --update
echo "minlen=14" >> /etc/security/pwquality.conf

echo "STIG hardening completed."
